const config = {
    server_path: 'http://localhost:4000'
}

export default config;